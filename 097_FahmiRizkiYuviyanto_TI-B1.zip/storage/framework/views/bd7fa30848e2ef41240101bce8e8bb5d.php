<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pemilik</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style_data_pemilik_new.css')); ?>">
</head>
<body>
    <!-- ========== MAIN CONTENT ========== -->
    <div class="container">
        <!-- ========== MAIN CONTENT WRAPPER ========== -->
        <div class="main-content">
            <!-- ========== PAGE HEADER ========== -->
            <div class="page-header">
                <h1 class="page-title">Data Pemilik</h1>
                <p class="page-subtitle">Kelola data pemilik hewan yang terdaftar dalam sistem.</p>
            </div>
        
        <!-- ========== BUTTON SECTION ========== -->
        <div class="button-section">
            <!-- Tombol navigasi berdasarkan role -->
            <?php if(isset($role) && $role === 'resepsionis'): ?>
                <a class="btn btn-primary" href="<?php echo e(route('resepsionis.tambah-pemilik')); ?>">+ Tambah Pemilik</a>
                <a class="btn btn-secondary" href="<?php echo e(route('resepsionis.dashboard')); ?>">Kembali ke Dashboard</a>
            <?php endif; ?>
            
            <?php if(isset($role) && $role === 'administrator'): ?>
                <a class="btn btn-secondary" href="<?php echo e(url('/data_master')); ?>">Kembali ke Dashboard</a>
            <?php endif; ?>
        </div>
        
        <!-- ========== TABEL DATA PEMILIK ========== -->
        <div class="table-container">
            <table class="data-table <?php echo e(isset($role) && $role === 'administrator' ? 'role-admin' : 'role-resepsionis'); ?>">
                <thead>
                    <tr>
                        <th class="col-id">ID</th>
                        <th class="col-name">NAMA PEMILIK</th>
                        <th class="col-wa">NO WHATSAPP</th>
                        <th class="col-address">ALAMAT</th>
                        <th class="col-userid">ID USER</th>
                        <?php if(isset($role) && $role === 'administrator'): ?>
                            <th class="col-action">AKSI</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pemilikList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="col-id"><?php echo e($p->idpemilik); ?></td>
                        <td class="col-name"><?php echo e($p->user->nama ?? 'N/A'); ?></td>
                        <td class="col-wa"><?php echo e($p->no_wa); ?></td>
                        <td class="col-address"><?php echo e($p->alamat); ?></td>
                        <td class="col-userid"><?php echo e($p->iduser); ?></td>
                        
                        <!-- Tombol aksi hanya untuk administrator -->
                        <?php if(isset($role) && $role === 'administrator'): ?>
                        <td class="col-action">
                            <div class="actions-inline">
                                <a class="btn-edit" href="<?php echo e(route('admin.pemilik.edit', $p->iduser)); ?>">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.pemilik.destroy', $p->idpemilik)); ?>" class="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-delete" onclick="return confirm('Yakin ingin menghapus data pemilik ini?')">Hapus</button>
                                </form>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="empty-row">
                        <td colspan="<?php echo e(isset($role) && $role === 'administrator' ? '6' : '5'); ?>">Belum ada data pemilik terdaftar.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- END MAIN CONTENT WRAPPER -->
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\modul9laravel\resources\views/admin/Pemilik/data_pemilik.blade.php ENDPATH**/ ?>