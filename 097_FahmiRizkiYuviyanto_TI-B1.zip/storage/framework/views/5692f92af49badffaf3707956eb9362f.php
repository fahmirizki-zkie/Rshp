<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Jenis Hewan - Administrator</title>
    
    <!-- CSS Files untuk styling -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style_jenis_hewan.css')); ?>" />
</head>
<body>
    <!-- ========== MAIN CONTENT ========== -->
    <div class="container">
        <!-- ========== MAIN CONTENT WRAPPER ========== -->
        <div class="main-content">
            <!-- ========== PAGE HEADER ========== -->
            <div class="page-header">
                <h1 class="page-title">Data Jenis Hewan</h1>
                <p class="page-subtitle">Kelola jenis hewan yang tersedia dalam sistem.</p>
            </div>
            
            <!-- ========== BUTTON SECTION ========== -->
            <div class="button-section">
                <a href="<?php echo e(url('/data_master')); ?>" class="btn btn-secondary">Kembali ke Dashboard</a>
            </div>
        
        <!-- ========== ALERT MESSAGES ========== -->
        <?php
            $status = session('status') ?? request('status');
            $msg = session('msg') ?? request('msg');
        ?>
        <?php if(!empty($status) && !empty($msg)): ?>
            <?php $alertClass = $status === 'success' ? 'alert--success' : 'alert--error'; ?>
            <div class="alert <?php echo e($alertClass); ?>">
                <?php echo e($msg); ?>

            </div>
        <?php endif; ?>

        <!-- ========== FORM TAMBAH JENIS HEWAN (disabled) ========== -->
        
        <!-- ========== TABEL DATA JENIS HEWAN ========== -->
        <div class="table-container">
            <table class="data-table">
                <!-- Header tabel -->
                <thead>
                    <tr>
                        <th class="col-id">ID</th>
                        <th class="col-name">NAMA JENIS HEWAN</th>
                    </tr>
                </thead>
                
                <!-- Data rows -->
                <tbody>
                    <!-- Loop untuk menampilkan setiap jenis hewan -->
                    <?php $__empty_1 = true; $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <!-- ID Jenis Hewan -->
                        <td class="col-id"><?php echo e($jenis->idjenis_hewan); ?></td>

                        <!-- Nama Jenis Hewan -->
                        <td class="col-name"><?php echo e($jenis->nama_jenis_hewan); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="empty-row">
                        <td colspan="2">Belum ada data jenis hewan. Silakan tambah jenis hewan baru.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- END MAIN CONTENT WRAPPER -->
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\modul9laravel\resources\views/jenis_hewan/jenis_hewan.blade.php ENDPATH**/ ?>